## test

This package uses integration tests for testing.

See `example/README.md` for more info.
